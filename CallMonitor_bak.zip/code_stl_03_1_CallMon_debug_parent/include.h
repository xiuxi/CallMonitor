#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <string>
#include <vector>
#include <sstream>
#include <limits>

#include <algorithm>
#include <iostream>
#include <list>
#include <numeric>
#include <random>
#include <vector>
#include <numeric>
#include <ctime>
#include <cmath>
#include <ctime>
#include <functional>
#include <stdio.h>
#include <sys/types.h>
//#include <dirent.h>
//#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <array>
#include <iostream>
#include <ctime> 
#include <cstdlib> //qsort, bsearch, NULL
#include <array>
using namespace std;
