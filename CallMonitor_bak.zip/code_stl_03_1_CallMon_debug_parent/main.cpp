/*
#include "include.h"
using namespace std;


int main()
{
	array<int, 3> arr = {1,2,3};
	bool empty = arr.empty();
	for (int a : arr) {
		cout << a << endl;
	}
	return 0;
}
*/

