
#include <windows.h>
#include <iostream>
#include "include.h"

void test() {
    //cout << "hello aaaa \n" << endl;
}

int main(int argc,char *argv[])
{
    test();
	
	return 0;
}
